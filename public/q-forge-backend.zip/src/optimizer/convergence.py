"""
Convergence-speed benchmark (plan's original ask, not yet built until now):
how many generations does each algorithm need to reach 95% of its own
best achievable hypervolume, at the SAME population size? This is a
different question from the main benchmark.py protocol (which only
compares final quality) - it isolates HOW FAST each algorithm gets there,
independent of whether it ends up ahead or behind.

Method: for each algorithm, run at increasing generation budgets
(10, 25, 50, 75, 100, 150), 3 seeds each, and record hypervolume at each
budget. "Convergence point" = the smallest generation budget whose mean
HV is >= 95% of the mean HV at the largest budget tested (150 gens).
"""
from __future__ import annotations
import time
import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.optimizer.encoding import Scenario
from src.optimizer.qiea import run_qiea
from src.optimizer.baselines import nsga2_pymoo
from src.models.predict_api import FuelPredictor

GEN_BUDGETS = [10, 25, 50, 75, 100, 150]
CEILING_GEN = 400  # a much larger budget used ONLY to estimate each
                    # algorithm's asymptotic ceiling - comparing against
                    # the last swept point (150) is circular, since it's
                    # trivially 100% of itself by construction
N_POP = 40
N_SEEDS = 3
CEILING_SEEDS = 2


def hypervolume(archive: list[dict], ref_point: np.ndarray) -> float:
    from pymoo.indicators.hv import HV
    if not archive:
        return 0.0
    F = np.array([e["obj"] for e in archive])
    return float(HV(ref_point=ref_point)(F))


def run(scenario_path: str, out_csv: str):
    scenario = Scenario.from_yaml(scenario_path)
    predictor = FuelPredictor.from_synthetic()

    print(f"Convergence sweep: generations={GEN_BUDGETS}, {N_SEEDS} seeds, pop={N_POP}\n")

    rows = []
    all_objs = []
    cache: dict[tuple, list[dict]] = {}

    for algo, runner in [("qiea", run_qiea), ("nsga2", nsga2_pymoo)]:
        for gen in GEN_BUDGETS:
            for seed in range(N_SEEDS):
                t0 = time.time()
                if algo == "qiea":
                    archive, _ = runner(scenario, predictor, n_pop=N_POP, n_generations=gen, seed=seed, verbose=False)
                else:
                    archive = runner(scenario, predictor, n_pop=N_POP, n_generations=gen, seed=seed)
                elapsed = time.time() - t0
                cache[(algo, gen, seed)] = archive
                all_objs.extend(e["obj"] for e in archive)
                print(f"{algo:6s} gen={gen:3d} seed={seed}  {elapsed:.2f}s  archive={len(archive)}")

    print(f"\n--- Ceiling reference runs (gen={CEILING_GEN}, {CEILING_SEEDS} seeds) ---")
    ceiling_cache: dict[tuple, list[dict]] = {}
    for algo, runner in [("qiea", run_qiea), ("nsga2", nsga2_pymoo)]:
        for seed in range(CEILING_SEEDS):
            t0 = time.time()
            if algo == "qiea":
                archive, _ = runner(scenario, predictor, n_pop=N_POP, n_generations=CEILING_GEN, seed=seed, verbose=False)
            else:
                archive = runner(scenario, predictor, n_pop=N_POP, n_generations=CEILING_GEN, seed=seed)
            elapsed = time.time() - t0
            ceiling_cache[(algo, seed)] = archive
            all_objs.extend(e["obj"] for e in archive)
            print(f"{algo:6s} gen={CEILING_GEN} seed={seed}  {elapsed:.2f}s  archive={len(archive)}")

    all_objs = np.array(all_objs)
    ref_point = all_objs.max(axis=0) * 1.1
    ref_point = np.where(ref_point <= 0, 1e-3, ref_point)
    print(f"\nShared reference point: {ref_point}\n")

    for (algo, gen, seed), archive in cache.items():
        hv = hypervolume(archive, ref_point)
        rows.append({"algorithm": algo, "generations": gen, "seed": seed, "hypervolume": hv})

    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(out_csv), exist_ok=True)
    df.to_csv(out_csv, index=False)

    ceiling_hv = {}
    for algo in ["qiea", "nsga2"]:
        hvs = [hypervolume(ceiling_cache[(algo, s)], ref_point) for s in range(CEILING_SEEDS)]
        ceiling_hv[algo] = float(np.mean(hvs))

    print(f"{'='*60}\nCONVERGENCE SUMMARY (mean HV per generation budget)\n{'='*60}")
    print(f"Ceiling estimates (gen={CEILING_GEN}): qiea={ceiling_hv['qiea']:,.0f}  nsga2={ceiling_hv['nsga2']:,.0f}\n")
    for algo in ["qiea", "nsga2"]:
        sub = df[df.algorithm == algo].groupby("generations")["hypervolume"].mean()
        ceiling = ceiling_hv[algo]
        print(f"{algo}:")
        convergence_gen = None
        for gen, hv in sub.items():
            pct = hv / ceiling * 100
            reached = pct >= 95 and convergence_gen is None
            if reached:
                convergence_gen = gen
            print(f"  gen={gen:3d}  HV={hv:,.0f}  ({pct:.1f}% of {CEILING_GEN}-gen ceiling){' <- 95% reached' if reached else ''}")
        if convergence_gen:
            print(f"  => reaches 95% of its (higher-budget-estimated) ceiling by generation {convergence_gen}")
        else:
            print(f"  => does NOT reach 95% of its ceiling within the tested range up to {GEN_BUDGETS[-1]} generations - still improving")
        print()

    print(f"Wrote {out_csv}")
    return df


if __name__ == "__main__":
    scenario_path = os.path.join(os.path.dirname(__file__), "..", "..", "configs", "scenario.yaml")
    out_csv = os.path.join(os.path.dirname(__file__), "..", "..", "results", "convergence_table.csv")
    run(scenario_path, out_csv)
