"""
Decision encoding for the fleet plan (plan Sec 7.1) plus the scenario
definition it operates over.

One chromosome = one multi-week fleet plan. Genes are (route, week, slot).
Each gene's allele is a flattened triple:

    (vessel_class: 4) x (fuel: 5) x (speed_bucket: 3) -> 60 discrete alleles

This module owns the encode/decode logic and the Scenario dataclass so
repair.py and fitness.py both work off the same ground truth.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import yaml
import os

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from src.models.physics import VESSEL_CLASSES, DWT_LOOKUP, DESIGN_SPEED_KN

FUEL_OPTIONS = ["MDO", "VLSFO", "LNG", "MeOH", "NH3", "H2"]
SPEED_BUCKETS = {"eco": 0.60, "design": 0.85, "full": 1.00}
SPEED_BUCKET_NAMES = list(SPEED_BUCKETS.keys())
SHORE_POWER_OPTIONS = [False, True]

N_VESSEL = len(VESSEL_CLASSES)
N_FUEL = len(FUEL_OPTIONS)
N_SPEED = len(SPEED_BUCKETS)
N_SHORE = len(SHORE_POWER_OPTIONS)
N_ALLELES = N_VESSEL * N_FUEL * N_SPEED * N_SHORE  # 4 * 6 * 3 * 2 = 144


def encode_allele(vessel_idx: int, fuel_idx: int, speed_idx: int, shore_idx: int = 0) -> int:
    return ((vessel_idx * N_FUEL + fuel_idx) * N_SPEED + speed_idx) * N_SHORE + shore_idx


def decode_allele(allele: int) -> tuple[str, str, str, bool]:
    """Returns (vessel_class, fuel, speed_bucket_name, use_shore_power).
    use_shore_power is a per-leg decision: plug into port grid power for
    the auxiliary/hotel load while docked, instead of running it on the
    ship's own (propulsion) fuel - independent of which propulsion fuel
    was chosen for the voyage itself."""
    shore_idx = allele % N_SHORE
    rem = allele // N_SHORE
    speed_idx = rem % N_SPEED
    rem = rem // N_SPEED
    fuel_idx = rem % N_FUEL
    vessel_idx = rem // N_FUEL
    return VESSEL_CLASSES[vessel_idx], FUEL_OPTIONS[fuel_idx], SPEED_BUCKET_NAMES[speed_idx], bool(shore_idx)


def alleles_for_fuel(fuel: str) -> list[int]:
    """All allele indices that use a given fuel - used by the fuel-
    availability repair operator to remap without touching vessel/speed."""
    fuel_idx = FUEL_OPTIONS.index(fuel)
    return [
        encode_allele(v, fuel_idx, s, sh)
        for v in range(N_VESSEL) for s in range(N_SPEED) for sh in range(N_SHORE)
    ]


def with_fuel(allele: int, new_fuel: str) -> int:
    """Same vessel_class + speed_bucket + shore-power choice, different fuel."""
    vessel_class, _, speed_name, use_shore = decode_allele(allele)
    speed_idx = SPEED_BUCKET_NAMES.index(speed_name)
    vessel_idx = VESSEL_CLASSES.index(vessel_class)
    fuel_idx = FUEL_OPTIONS.index(new_fuel)
    return encode_allele(vessel_idx, fuel_idx, speed_idx, int(use_shore))


def with_vessel_class(allele: int, new_vessel_class: str) -> int:
    """Same fuel + speed_bucket + shore-power choice, different (usually
    bigger) vessel."""
    _, fuel, speed_name, use_shore = decode_allele(allele)
    fuel_idx = FUEL_OPTIONS.index(fuel)
    speed_idx = SPEED_BUCKET_NAMES.index(speed_name)
    vessel_idx = VESSEL_CLASSES.index(new_vessel_class)
    return encode_allele(vessel_idx, fuel_idx, speed_idx, int(use_shore))


@dataclass
class Route:
    name: str
    distance_nm: float
    weeks: int
    slots_per_week: int
    demand_dwt_per_week: float
    fuel_availability: list[str]
    origin_port: str | None = None
    destination_port: str | None = None

    @property
    def n_genes(self) -> int:
        return self.weeks * self.slots_per_week


@dataclass
class Scenario:
    routes: list[Route]
    year: int
    eua_price_usd_per_ton: float
    fuel_price_usd_per_ton: dict[str, float]
    w_delay_usd_per_hour: float
    available_hours_per_week: float

    @property
    def n_genes(self) -> int:
        return sum(r.n_genes for r in self.routes)

    def gene_route_map(self) -> list[int]:
        """gene index -> index into self.routes, so fitness/repair know
        which route (and therefore which demand/availability) each gene
        belongs to."""
        mapping = []
        for i, r in enumerate(self.routes):
            mapping.extend([i] * r.n_genes)
        return mapping

    def gene_week_map(self) -> list[int]:
        """gene index -> week number within its route (0-indexed) - genes
        for a route are laid out slot-major within each week."""
        mapping = []
        for r in self.routes:
            for w in range(r.weeks):
                mapping.extend([w] * r.slots_per_week)
        return mapping

    @classmethod
    def from_yaml(cls, path: str) -> "Scenario":
        with open(path) as f:
            cfg = yaml.safe_load(f)
        routes = [Route(**r) for r in cfg["routes"]]
        return cls(
            routes=routes,
            year=cfg["year"],
            eua_price_usd_per_ton=cfg["eua_price_usd_per_ton"],
            fuel_price_usd_per_ton=cfg["fuel_price_usd_per_ton"],
            w_delay_usd_per_hour=cfg["w_delay_usd_per_hour"],
            available_hours_per_week=cfg["available_hours_per_week"],
        )
