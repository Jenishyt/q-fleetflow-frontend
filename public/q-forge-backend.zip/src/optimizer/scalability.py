"""
Scalability benchmark (plan's original ask, not yet built until now): how
does each algorithm's wall-clock time and solution quality change as the
fleet-planning problem gets bigger? We vary the number of routes (more
genes = bigger search space) at a FIXED population/generation budget and
measure runtime + hypervolume at each scale.
"""
from __future__ import annotations
import time
import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.optimizer.encoding import Scenario, Route
from src.optimizer.qiea import run_qiea
from src.optimizer.baselines import nsga2_pymoo
from src.models.predict_api import FuelPredictor
from src.data.ports import PORTS

N_POP = 40
N_GEN = 150
N_SEEDS = 3
ROUTE_COUNTS = [3, 6, 9, 12]
FUEL_SETS = [
    ["MDO", "VLSFO", "LNG"], ["MDO", "VLSFO"], ["MDO", "VLSFO", "LNG", "MeOH"],
]


def make_scenario(n_routes: int, seed: int = 0) -> Scenario:
    """Synthetic scenario generator: cycles through the real ports database
    to build n_routes plausible routes, so scalability testing doesn't
    depend on hand-writing YAML for every size tested."""
    rng = np.random.default_rng(seed)
    routes = []
    for i in range(n_routes):
        origin = PORTS[i % len(PORTS)]
        dest = PORTS[(i + 3) % len(PORTS)]
        # rough great-circle-ish distance proxy (not exact haversine, fine
        # for a synthetic scalability test - documented as illustrative)
        dist = float(np.hypot(origin["lat"] - dest["lat"], origin["lon"] - dest["lon"]) * 55 + 200)
        routes.append(Route(
            name=f"R{i}_{origin['name']}_{dest['name']}",
            distance_nm=round(dist, 1),
            weeks=4, slots_per_week=2,
            demand_dwt_per_week=float(rng.integers(20000, 60000)),
            fuel_availability=FUEL_SETS[i % len(FUEL_SETS)],
            origin_port=origin["name"], destination_port=dest["name"],
        ))
    return Scenario(
        routes=routes, year=2026, eua_price_usd_per_ton=80,
        fuel_price_usd_per_ton={"MDO": 650, "VLSFO": 600, "LNG": 550, "MeOH": 700, "NH3": 900, "H2": 1400},
        w_delay_usd_per_hour=50, available_hours_per_week=72,
    )


def hypervolume(archive: list[dict], ref_point: np.ndarray) -> float:
    from pymoo.indicators.hv import HV
    if not archive:
        return 0.0
    F = np.array([e["obj"] for e in archive])
    return float(HV(ref_point=ref_point)(F))


def run(out_csv: str):
    predictor = FuelPredictor.from_synthetic()
    print(f"Scalability sweep: routes={ROUTE_COUNTS}, pop={N_POP}, gen={N_GEN}, {N_SEEDS} seeds\n")

    rows = []
    all_objs = []
    cache: dict[tuple, list[dict]] = {}

    for n_routes in ROUTE_COUNTS:
        scenario = make_scenario(n_routes)
        print(f"-- {n_routes} routes ({scenario.n_genes} genes) --")
        for algo, runner in [("qiea", run_qiea), ("nsga2", nsga2_pymoo)]:
            for seed in range(N_SEEDS):
                t0 = time.time()
                if algo == "qiea":
                    archive, _ = runner(scenario, predictor, n_pop=N_POP, n_generations=N_GEN, seed=seed, verbose=False)
                else:
                    archive = runner(scenario, predictor, n_pop=N_POP, n_generations=N_GEN, seed=seed)
                elapsed = time.time() - t0
                cache[(n_routes, algo, seed)] = archive
                all_objs.extend(e["obj"] for e in archive)
                print(f"  {algo:6s} seed={seed}  {elapsed:.2f}s  archive={len(archive)}")
                rows.append({"n_routes": n_routes, "n_genes": scenario.n_genes, "algorithm": algo,
                             "seed": seed, "wall_clock_s": elapsed, "archive_size": len(archive)})

    all_objs = np.array(all_objs)
    ref_point = all_objs.max(axis=0) * 1.1
    ref_point = np.where(ref_point <= 0, 1e-3, ref_point)

    for row in rows:
        row["hypervolume"] = hypervolume(cache[(row["n_routes"], row["algorithm"], row["seed"])], ref_point)

    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(out_csv), exist_ok=True)
    df.to_csv(out_csv, index=False)

    print(f"\n{'='*70}\nSCALABILITY SUMMARY (mean across {N_SEEDS} seeds)\n{'='*70}")
    print(f"{'routes':>7} {'genes':>6} {'algo':>7} {'time(s)':>9} {'HV':>16}")
    for n_routes in ROUTE_COUNTS:
        for algo in ["qiea", "nsga2"]:
            sub = df[(df.n_routes == n_routes) & (df.algorithm == algo)]
            print(f"{n_routes:>7} {sub.n_genes.iloc[0]:>6} {algo:>7} {sub.wall_clock_s.mean():>9.2f} {sub.hypervolume.mean():>16,.0f}")

    print(f"\nWrote {out_csv}")
    return df


if __name__ == "__main__":
    out_csv = os.path.join(os.path.dirname(__file__), "..", "..", "results", "scalability_table.csv")
    run(out_csv)
