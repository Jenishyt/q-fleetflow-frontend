#!/bin/bash
# Q-FORGE backend - one-click setup and run (Mac/Linux)
# Run with: bash setup_and_run.sh

set -e
echo "============================================"
echo " Q-FORGE backend - setup and run"
echo "============================================"

if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 was not found. Install Python 3.11/3.12 first: https://www.python.org/downloads/"
    exit 1
fi
echo "[OK] Python found."

if [ ! -d "venv" ]; then
    echo "Creating virtual environment, this happens only once..."
    python3 -m venv venv
fi

source venv/bin/activate

echo "Installing dependencies - first run takes a few minutes, please wait..."
pip install -q -r requirements.txt
echo "[OK] Dependencies installed."

echo "============================================"
echo " Starting the backend at http://localhost:8000"
echo " Open http://localhost:8000/docs in your browser to try it."
echo " Press CTRL+C to stop."
echo "============================================"
uvicorn src.api.main:app --port 8000
