@echo off
REM Q-FORGE backend - one-click setup and run (Windows)
REM Double-click this file, or run it from a terminal: setup_and_run.bat

echo ============================================
echo  Q-FORGE backend - setup and run
echo ============================================
echo.

REM --- Check Python is installed ---
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python was not found on this PC.
    echo Please install Python 3.11 or 3.12 from https://www.python.org/downloads/
    echo IMPORTANT: during install, check the box "Add Python to PATH"
    echo Then run this file again.
    pause
    exit /b 1
)
echo [OK] Python found.

REM --- Create the virtual environment if it doesn't exist yet ---
if not exist venv (
    echo Creating virtual environment, this happens only once...
    python -m venv venv
)

REM --- Activate it ---
call venv\Scripts\activate.bat

REM --- Install dependencies (skips already-installed ones on repeat runs) ---
echo Installing dependencies - first run takes a few minutes, please wait...
pip install -q -r requirements.txt
if errorlevel 1 (
    echo ERROR: dependency installation failed. See the error above.
    pause
    exit /b 1
)
echo [OK] Dependencies installed.
echo.

REM --- Start the server ---
echo ============================================
echo  Starting the backend at http://localhost:8000
echo  Open http://localhost:8000/docs in your browser to try it.
echo  Press CTRL+C in this window to stop the server.
echo ============================================
echo.
uvicorn src.api.main:app --port 8000

pause
